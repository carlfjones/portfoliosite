<h1> Carlexa </h1>

<h3> Speech Recognizer Project </h3>

<p>For this project I wanted to learn about the speech recognition functionality of the DOM, along with continuing to practice working with API's.</p><br>

Home Screen:
![Image of Home](https://github.com/carlfjones/ai_speech/blob/master/Readme%20pics/Home.png)<br>
 
Time function:<br>
Will tell you current time, when you ask what time is it?
![Image of Time](https://github.com/carlfjones/ai_speech/blob/master/Readme%20pics/Time.png)<br>

Randomly generated joke function:<br>
When you ask for a joke, will fetch a joke from joke API and deliver with pause.
![Image of Joke](https://github.com/carlfjones/ai_speech/blob/master/Readme%20pics/Joke.png)<br>

Randomly generated cat advice function: <br>
Will randomly generate a cat img from API, and attach a motivational quote < 150 chars from a different API.
![Image of Cat](https://github.com/carlfjones/ai_speech/blob/master/Readme%20pics/Cat.png)<br>
